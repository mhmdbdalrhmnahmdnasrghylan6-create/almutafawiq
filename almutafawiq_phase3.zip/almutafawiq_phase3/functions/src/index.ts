import { createHash } from 'node:crypto';
import { initializeApp } from 'firebase-admin/app';
import { getFirestore, Timestamp, FieldValue } from 'firebase-admin/firestore';
import { HttpsError, onCall } from 'firebase-functions/v2/https';

initializeApp();
const db = getFirestore();

/** A code document stores only SHA-256(code) as its document ID. */
export const activateSubscription = onCall(async (request) => {
  if (!request.auth) throw new HttpsError('unauthenticated', 'سجّل الدخول أولاً.');
  const code = String(request.data?.code ?? '').trim().toUpperCase();
  if (!/^[A-Z0-9-]{8,32}$/.test(code)) {
    throw new HttpsError('invalid-argument', 'صيغة كود الاشتراك غير صحيحة.');
  }

  const hash = createHash('sha256').update(code).digest('hex');
  const codeRef = db.collection('subscriptionCodes').doc(hash);
  const subRef = db.collection('subscriptions').doc(request.auth.uid);

  return db.runTransaction(async (tx) => {
    const codeSnap = await tx.get(codeRef);
    if (!codeSnap.exists) throw new HttpsError('not-found', 'كود الاشتراك غير صحيح.');
    const data = codeSnap.data()!;
    if (data.usedAt || data.disabled === true) {
      throw new HttpsError('failed-precondition', 'هذا الكود مستخدم أو موقوف.');
    }
    const durationDays = Number(data.durationDays);
    if (!Number.isInteger(durationDays) || durationDays < 1 || durationDays > 366) {
      throw new HttpsError('failed-precondition', 'إعداد مدة الاشتراك غير صالح.');
    }

    const now = Timestamp.now();
    const oldSub = await tx.get(subRef);
    const oldExpiry = oldSub.exists ? oldSub.data()?.expiresAt as Timestamp | undefined : undefined;
    const startMillis = oldExpiry && oldExpiry.toMillis() > now.toMillis()
      ? oldExpiry.toMillis() : now.toMillis();
    const expiresAt = Timestamp.fromMillis(startMillis + durationDays * 86400000);

    tx.update(codeRef, {
      usedAt: FieldValue.serverTimestamp(),
      usedBy: request.auth.uid,
    });
    tx.set(subRef, {
      status: 'active',
      expiresAt,
      updatedAt: FieldValue.serverTimestamp(),
      lastCodeHash: hash,
    });
    return { success: true, expiresAt: expiresAt.toDate().toISOString() };
  });
});
