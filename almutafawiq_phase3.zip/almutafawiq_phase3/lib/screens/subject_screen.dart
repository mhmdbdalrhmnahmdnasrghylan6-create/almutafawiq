import 'package:flutter/material.dart';
import '../data/sample_data.dart';
import '../models/subject.dart';
import 'lesson_screen.dart';

class SubjectScreen extends StatelessWidget {
  final Subject subject;
  const SubjectScreen({super.key, required this.subject});

  @override
  Widget build(BuildContext context) {
    final lessons = lessonsBySubject[subject.id] ?? const <Lesson>[];
    return Scaffold(
      appBar: AppBar(title: Text(subject.title, style: const TextStyle(fontWeight: FontWeight.bold))),
      body: ListView(padding: const EdgeInsets.all(18), children: [
        Container(padding: const EdgeInsets.all(18), decoration: BoxDecoration(color: subject.color.withOpacity(.10), borderRadius: BorderRadius.circular(18)), child: Row(children: [Icon(subject.icon, color: subject.color, size: 42), const SizedBox(width: 14), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(subject.title, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 19)), Text('${lessons.length} دروس تجريبية', style: const TextStyle(color: Colors.black54))]))])),
        const SizedBox(height: 22), const Text('الدروس', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)), const SizedBox(height: 10),
        ...lessons.asMap().entries.map((entry) {
          final lesson = entry.value;
          return Card(color: Colors.white, elevation: 0, margin: const EdgeInsets.only(bottom: 10), child: ListTile(contentPadding: const EdgeInsets.symmetric(horizontal: 15, vertical: 8), leading: CircleAvatar(backgroundColor: subject.color.withOpacity(.12), child: Text('${entry.key + 1}', style: TextStyle(color: subject.color, fontWeight: FontWeight.bold))), title: Text(lesson.title, style: const TextStyle(fontWeight: FontWeight.bold)), subtitle: Text(lesson.summary, maxLines: 2, overflow: TextOverflow.ellipsis), trailing: Icon(lesson.isFree ? Icons.play_circle_outline : Icons.lock_outline, color: lesson.isFree ? subject.color : Colors.orange), onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => LessonScreen(subject: subject, lesson: lesson)))),
          );
        }),
        const SizedBox(height: 12), const Text('المحتوى الظاهر هنا بيانات تجريبية للتصميم، وسيُستبدل بمحتوى المنهج المعتمد بعد إدخاله.', style: TextStyle(color: Colors.black54, height: 1.5, fontSize: 12)),
      ]),
    );
  }
}
