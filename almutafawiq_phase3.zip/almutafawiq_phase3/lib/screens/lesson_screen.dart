import 'package:flutter/material.dart';
import '../models/subject.dart';

class LessonScreen extends StatelessWidget {
  final Subject subject;
  final Lesson lesson;
  const LessonScreen({super.key, required this.subject, required this.lesson});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('تفاصيل الدرس')),
      body: ListView(padding: const EdgeInsets.all(20), children: [
        Container(height: 170, decoration: BoxDecoration(color: subject.color.withOpacity(.12), borderRadius: BorderRadius.circular(20)), child: Icon(Icons.play_circle_fill_rounded, size: 76, color: subject.color)),
        const SizedBox(height: 22), Text(subject.title, style: TextStyle(color: subject.color, fontWeight: FontWeight.bold)),
        const SizedBox(height: 8), Text(lesson.title, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w900)),
        const SizedBox(height: 16), const Text('ملخص الدرس', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
        const SizedBox(height: 8), Text(lesson.summary, style: const TextStyle(fontSize: 16, height: 1.8)),
        const SizedBox(height: 18),
        Container(padding: const EdgeInsets.all(16), decoration: BoxDecoration(color: const Color(0xFFFFF4DE), borderRadius: BorderRadius.circular(14)), child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [const Icon(Icons.info_outline, color: Colors.orange), const SizedBox(width: 10), const Expanded(child: Text('هذا نموذج توضيحي لصفحة الدرس. سنضيف نص الكتاب والفيديو والملخص والأسئلة بعد تجهيز المحتوى المرخّص والمعتمد.', style: TextStyle(height: 1.6)))])),
        const SizedBox(height: 22),
        OutlinedButton.icon(onPressed: () => ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('سيتم تفعيل الاختبارات في المرحلة القادمة'))), icon: const Icon(Icons.quiz_outlined), label: const Text('اختبر فهمك')),
      ]),
    );
  }
}
