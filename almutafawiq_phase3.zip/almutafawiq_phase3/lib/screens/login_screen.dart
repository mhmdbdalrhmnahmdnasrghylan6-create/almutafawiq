import 'package:flutter/material.dart';
import 'home_screen.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});
  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final nameController = TextEditingController();
  final codeController = TextEditingController();
  bool useCode = false;

  @override
  void dispose() { nameController.dispose(); codeController.dispose(); super.dispose(); }

  void continueToApp() {
    if (nameController.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('اكتب اسم الطالب أولاً')));
      return;
    }
    Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => HomeScreen(studentName: nameController.text.trim())));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(child: Center(child: SingleChildScrollView(padding: const EdgeInsets.all(24), child: ConstrainedBox(constraints: const BoxConstraints(maxWidth: 440), child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        const SizedBox(height: 24),
        Container(width: 92, height: 92, alignment: Alignment.center, decoration: BoxDecoration(color: const Color(0xFFE5EEFC), borderRadius: BorderRadius.circular(28)), child: const Icon(Icons.school_rounded, size: 54, color: Color(0xFF173B68))),
        const SizedBox(height: 18),
        const Text('المتفوق', textAlign: TextAlign.center, style: TextStyle(fontSize: 34, fontWeight: FontWeight.w900, color: Color(0xFF173B68))),
        const SizedBox(height: 8),
        const Text('طريقك للفهم والنجاح', textAlign: TextAlign.center, style: TextStyle(fontSize: 16, color: Colors.black54)),
        const SizedBox(height: 34),
        const Text('مرحباً بك 👋', style: TextStyle(fontSize: 23, fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        const Text('أدخل اسمك للبدء في التعلم'),
        const SizedBox(height: 18),
        TextField(controller: nameController, textInputAction: TextInputAction.next, decoration: const InputDecoration(prefixIcon: Icon(Icons.person_outline), hintText: 'اسم الطالب')),
        const SizedBox(height: 12),
        SwitchListTile(value: useCode, onChanged: (v) => setState(() => useCode = v), contentPadding: EdgeInsets.zero, title: const Text('لديّ كود اشتراك')),
        if (useCode) ...[
          const SizedBox(height: 6),
          TextField(controller: codeController, decoration: const InputDecoration(prefixIcon: Icon(Icons.key), hintText: 'أدخل كود الاشتراك')),
          const SizedBox(height: 8),
          const Text('تنبيه: التحقق الفعلي من الكود سيُربط بالخادم في المرحلة التالية.', style: TextStyle(fontSize: 12, color: Colors.black54)),
        ],
        const SizedBox(height: 20),
        FilledButton(onPressed: continueToApp, style: FilledButton.styleFrom(padding: const EdgeInsets.symmetric(vertical: 16), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14))), child: const Text('ابدأ التعلم', style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold))),
        const SizedBox(height: 18),
        const Text('الصف السادس • المنهج اليمني', textAlign: TextAlign.center, style: TextStyle(color: Colors.black45)),
      ]))))),
    );
  }
}
