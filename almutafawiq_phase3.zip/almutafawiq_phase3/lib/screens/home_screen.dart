import 'package:flutter/material.dart';
import '../data/sample_data.dart';
import '../models/subject.dart';
import 'subject_screen.dart';

class HomeScreen extends StatelessWidget {
  final String studentName;
  const HomeScreen({super.key, required this.studentName});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('المتفوق', style: TextStyle(fontWeight: FontWeight.w900)), actions: [IconButton(onPressed: () => showAboutDialog(context: context, applicationName: 'المتفوق', applicationVersion: '0.2.0', children: const [Text('تطبيق تعليمي تجريبي للصف السادس في المنهج اليمني.')]), icon: const Icon(Icons.info_outline))]),
      body: ListView(padding: const EdgeInsets.all(18), children: [
        Container(padding: const EdgeInsets.all(20), decoration: BoxDecoration(gradient: const LinearGradient(colors: [Color(0xFF173B68), Color(0xFF3977D5)]), borderRadius: BorderRadius.circular(22)), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('أهلاً ${studentName.isEmpty ? 'بك' : studentName}', style: const TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold)),
          const SizedBox(height: 8), const Text('ماذا تريد أن تتعلم اليوم؟', style: TextStyle(color: Colors.white70, fontSize: 15)),
          const SizedBox(height: 18), const Row(children: [Icon(Icons.menu_book_rounded, color: Colors.white), SizedBox(width: 8), Text('الصف السادس • المنهج اليمني', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w600))]),
        ])),
        const SizedBox(height: 24),
        const Text('المواد الدراسية', style: TextStyle(fontSize: 21, fontWeight: FontWeight.w900)),
        const SizedBox(height: 12),
        GridView.builder(shrinkWrap: true, physics: const NeverScrollableScrollPhysics(), itemCount: subjects.length, gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, crossAxisSpacing: 12, mainAxisSpacing: 12, childAspectRatio: 1.08), itemBuilder: (context, index) {
          final subject = subjects[index];
          return _SubjectCard(subject: subject, onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => SubjectScreen(subject: subject))));
        }),
        const SizedBox(height: 20),
        const Text('ابدأ بالمحتوى المجاني، ثم فعّل اشتراكك للوصول إلى بقية الدروس.', style: TextStyle(color: Colors.black54, height: 1.6)),
      ]),
    );
  }
}

class _SubjectCard extends StatelessWidget {
  final Subject subject;
  final VoidCallback onTap;
  const _SubjectCard({required this.subject, required this.onTap});
  @override
  Widget build(BuildContext context) => Material(color: Colors.white, borderRadius: BorderRadius.circular(18), child: InkWell(borderRadius: BorderRadius.circular(18), onTap: onTap, child: Padding(padding: const EdgeInsets.all(15), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
    Container(width: 48, height: 48, decoration: BoxDecoration(color: subject.color.withOpacity(.12), borderRadius: BorderRadius.circular(14)), child: Icon(subject.icon, color: subject.color, size: 28)),
    const Spacer(), Text(subject.title, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
    const SizedBox(height: 5), Text(subject.description, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Colors.black54, fontSize: 11, height: 1.4)),
  ]))));
}
