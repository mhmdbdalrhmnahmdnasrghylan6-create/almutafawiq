import 'package:flutter/material.dart';
import '../models/subject.dart';

const subjects = <Subject>[
  Subject(id: 'math', title: 'الرياضيات', description: 'الأعداد والعمليات والمسائل', icon: Icons.calculate_rounded, color: Color(0xFF3977D5)),
  Subject(id: 'science', title: 'العلوم', description: 'اكتشف جسمك والطبيعة من حولك', icon: Icons.science_rounded, color: Color(0xFF159B83)),
  Subject(id: 'arabic', title: 'اللغة العربية', description: 'القراءة والقواعد والتعبير', icon: Icons.menu_book_rounded, color: Color(0xFFB9782D)),
  Subject(id: 'quran', title: 'القرآن الكريم', description: 'التلاوة والحفظ والتفسير', icon: Icons.auto_stories_rounded, color: Color(0xFF298B65)),
  Subject(id: 'islamic', title: 'التربية الإسلامية', description: 'الدروس والقيم الإسلامية', icon: Icons.mosque_rounded, color: Color(0xFF8261B8)),
  Subject(id: 'history', title: 'الجغرافيا والتاريخ', description: 'بلادنا والعالم عبر الزمن', icon: Icons.public_rounded, color: Color(0xFFCF685C)),
];

const Map<String, List<Lesson>> lessonsBySubject = {
  'math': [
    Lesson(id: 'm1', title: 'مراجعة الأعداد والعمليات', summary: 'مراجعة تمهيدية لأهم المهارات الحسابية.', isFree: true),
    Lesson(id: 'm2', title: 'الكسور الاعتيادية', summary: 'التعرف على الكسور وطرق المقارنة بينها.'),
    Lesson(id: 'm3', title: 'حل المسائل الرياضية', summary: 'خطوات فهم المسألة واختيار العملية المناسبة.'),
  ],
  'science': [
    Lesson(id: 's1', title: 'الكائنات الحية', summary: 'خصائص الكائنات الحية واحتياجاتها.', isFree: true),
    Lesson(id: 's2', title: 'أجهزة جسم الإنسان', summary: 'تعرف مبسط على أجهزة الجسم ووظائفها.'),
  ],
  'arabic': [
    Lesson(id: 'a1', title: 'مهارات القراءة', summary: 'قراءة النص وفهم الفكرة الرئيسة.', isFree: true),
    Lesson(id: 'a2', title: 'الجملة الاسمية والفعلية', summary: 'تمييز أنواع الجمل ومكوناتها.'),
  ],
  'quran': [
    Lesson(id: 'q1', title: 'آداب تلاوة القرآن', summary: 'آداب التلاوة والاستماع.', isFree: true),
    Lesson(id: 'q2', title: 'مراجعة الحفظ', summary: 'إرشادات لتنظيم المراجعة والتثبيت.'),
  ],
  'islamic': [
    Lesson(id: 'i1', title: 'الأخلاق الحسنة', summary: 'أمثلة على الأخلاق في الحياة اليومية.', isFree: true),
    Lesson(id: 'i2', title: 'العبادات', summary: 'مفاهيم أساسية حول العبادات.'),
  ],
  'history': [
    Lesson(id: 'h1', title: 'موقع اليمن', summary: 'موقع اليمن وأهميته الجغرافية.', isFree: true),
    Lesson(id: 'h2', title: 'محطات من تاريخ اليمن', summary: 'التعرف على محطات تاريخية مختارة.'),
  ],
};
