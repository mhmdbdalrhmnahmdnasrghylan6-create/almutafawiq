import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:cloud_functions/cloud_functions.dart';

class ContentService {
  ContentService({FirebaseFirestore? firestore})
      : _db = firestore ?? FirebaseFirestore.instance;
  final FirebaseFirestore _db;

  Stream<QuerySnapshot<Map<String, dynamic>>> watchSubjects() => _db
      .collection('subjects')
      .where('active', isEqualTo: true)
      .orderBy('order')
      .snapshots();

  Stream<QuerySnapshot<Map<String, dynamic>>> watchLessons(String subjectId) =>
      _db.collection('subjects').doc(subjectId).collection('lessons')
          .where('published', isEqualTo: true)
          .orderBy('order')
          .snapshots();

  /// Calls the trusted server function; never activate codes in the client.
  Future<Map<String, dynamic>> activateSubscription(String code) async {
    final callable = FirebaseFunctions.instanceFor(region: 'us-central1')
        .httpsCallable('activateSubscription');
    final result = await callable.call<Map<String, dynamic>>({'code': code.trim()});
    return result.data;
  }
}
