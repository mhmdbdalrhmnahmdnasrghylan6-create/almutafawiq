import 'package:flutter/material.dart';

class Subject {
  final String id;
  final String title;
  final String description;
  final IconData icon;
  final Color color;
  const Subject({required this.id, required this.title, required this.description, required this.icon, required this.color});
}

class Lesson {
  final String id;
  final String title;
  final String summary;
  final bool isFree;
  const Lesson({required this.id, required this.title, required this.summary, this.isFree = false});
}
